﻿#include <stdio.h>
#include <stdlib.h>

/*
	-------------------------------------------------------------------------------
	일반적인 '게임'에 대한 정보들을 한 데 모아 담기 위해 미리 만들어 둔 부분
*/

struct Game
{
	char *data;
	void (*Initialize)(struct Game *);
	void (*Run)(struct Game *);
	void (*Finalize)(struct Game *);
};

struct Game *New_Game(size_t sizeOfData, void(*Initialize)(struct Game *), void(*Run)(struct Game *), void(*Finalize)(struct Game *))
{
	struct Game *result = (struct Game *)malloc(sizeof(struct Game));

	result->data = (char *)malloc(sizeOfData);
	result->Initialize = Initialize;
	result->Run = Run;
	result->Finalize = Finalize;

	return result;
}

void Delete_Game(struct Game *game)
{
	free(game->data);
	free(game);
}



/*
	------------------------------------------------
	'예시 게임'에 대한 Code들을 미리 정의해 둔 부분
*/

void Initialize_Press_3_to_win(struct Game *game)
{
	printf("게임을 초기화하고 있어요...");

	*(int *)&game->data[0] = 3;

	printf("끝!\n");
}

void Run_Press_3_to_win(struct Game *game)
{
	printf("게임을 시작해요!\n");

	printf("3을 입력하세요>");
	scanf("%d", &game->data[4]);

	if ( *(int *)&game->data[0] == *(int *)&game->data[4] )
		printf("훌륭해요!\n");
	else
		printf("아쉽네요...\n");

	printf("게임이 끝났어요.\n");
}

void Finalize_Press_3_to_win(struct Game *game)
{
	printf("게임용 Data를 정리하고 있어요...");

	// double 값 0은 0x0000000000000000에 해당해요
	*(double *)game->data = 0;

	printf("끝!\n");
}

struct Game *New_Press_3_to_win()
{
	struct Game *result = New_Game(8, Initialize_Press_3_to_win, Run_Press_3_to_win, Finalize_Press_3_to_win);

	return result;
}

void Delete_Press_3_to_win(struct Game *game)
{
	Delete_Game(game);
}


/*
	-------------------------------------------------------------------------------
	'내 게임' 자체, 그리고 이를 다루기 위한 Code들을 지금 정의해 볼 부분
*/

void Initialize_MyGame(struct Game *game)
{

}

void Run_MyGame(struct Game *game)
{

}

void Finalize_MyGame(struct Game *game)
{

}


struct Game *New_MyGame()
{
	struct Game *result = New_Game(8, Initialize_Press_3_to_win, Run_Press_3_to_win, Finalize_Press_3_to_win);



	return result;
}

void Delete_MyGame(struct Game *game)
{


	Delete_Game(game);
}



/*
	------------------------------------------------------------------------------
	미래에 작성하는 부분(...이긴 한데 일단 지금은 미리 만들어 두었어요)
*/

#define NUMBER_OF_GAMES 2

int main()
{
	struct Game *games[NUMBER_OF_GAMES];

	// Game object들 생성(형성시킴)
	games[0] = New_Press_3_to_win();
	games[1] = New_MyGame();

	while ( 1 )
	{
		struct Game *game_selected;

		// 게임 번호를 입력받기 위한 덕심 깃든 표현
		int choice = -1;

		do printf("실행할 게임 번호를 입력하세요 | 0 ~ %d>", NUMBER_OF_GAMES);
		while ( (scanf("%d", &choice) == 0 || choice < 0 || choice >= NUMBER_OF_GAMES) && printf("입력이 유효하지 않습니다.\n") );

		// 선택한 게임 실행
		printf("%d번 게임을 실행합니다.\n\n", choice);

		game_selected = games[choice];

		game_selected->Initialize(game_selected);
		game_selected->Run(game_selected);
		game_selected->Finalize(game_selected);

		printf("\n%d번 게임 실행이 끝났습니다.\n", choice);
	}

	// Game object들 파괴(소멸시킴) - 실제로 실행될 일은 없긴 함
	Delete_Press_3_to_win(games[0]);
	Delete_MyGame(games[1]);

	return 0;
}