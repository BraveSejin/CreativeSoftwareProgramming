﻿#include <iostream>
#include <string>

int main()
{
	// 헤더 파일 string(string.h 아님!)을 include하면 std::string 형식을 사용할 수 있게 돼요.
	// 사용법은 Python의 str 형식과 매우 비슷해요 --> 편해요!
	std::string str{ "Hello, World!" };

	std::cout << str << std::endl; // :은 콜론, endl 끝은 소문자 L

	return 0;
}
