﻿#include <stdio.h>

// 사용할 총 Data 크기에 따라 여기를 살짝 고쳐 주세요.
#define SIZE_DATA 4096

// 나중에 칸을 마련하기 위해 큰 공간을 미리 정의해 두기 위한 선언이에요.
int data[SIZE_DATA];

int main()
{
	/*
		칸 사용 계획
			data[0]: 입력받은 첫 번째 수
			data[1]: 입력받은 두 번째 수
			data[2]: 두 수의 합
	*/

	// 두 수 입력받아 담기(매너 prompt 출력도 해 주면 좋을 듯)


	// 담아 둔 두 수의 합을 계산하여 담기


	// 담아 둔 합 값을 print

	return 0;
}