﻿#include <iostream>
#include <iomanip>

/*
	소속 관계와 포함 관계, 멤버 선언/정의에 붙이는
	static specifier의 의의를 열람하기 위한 예시 파일입니다.

	복습할 때는...

	- 각 이름들에 마우스 포인터를 갖다 대어 해당 이름에 대한 소속 관계를 체크해 봐요.

	- 각 Data/Code/형식 이름에 대한 정의 내용물이 어디에 적혀 있는지,
	  컴파일러가 정의를 어디서 수행하는지 확인해 봐요

	- funcForTest() 정의 첫 줄을 고쳐가며 

	- funcForTest() 정의 중괄호 안에서 여러 이름들을 사용해 보면서 컴파일러의 lookup 양상을 체크해 봐요.
*/



/*
	아래 중괄호 안에 선언이 적혀 있는 이름들은
	모두 namespace yeshi '소속'이 돼요.

	- 어떤 이름을 특정 namespace 소속으로 만드는 유일한 방법은
	  선언을 그 namespace 중괄호 안에 적는 것이에요.

	- 이렇게 적어 둔 덩어리를 namespace 정의라 부를 수는 있지만...
	  namespace 정의에 대해 컴파일러가 위치/offset 값을 정의할 일은 없어요.

	- 이 중괄호 자체는 다른 중괄호 안에 적혀 있지 않으므로,
	  이름 yeshi는 'global 소속' 정도로 부를 수 있어요.
*/
namespace yeshi
{
	// yeshi 소속 구조체 이름을 소개하고 있어요. 구조체 정의는 yeshi 중괄호 밖에 있어요.
	struct S_DefinedOutside;

	// yeshi 소속 구조체에 대한 구조체 정의예요.
	struct S
	{
		// S 소속, static 안 붙은 멤버 변수 선언이에요.
		int data;

		// S 소속, static 붙은 멤버 변수 선언이에요.
		static int data_static;

		// S 소속, static 안 붙은 멤버 함수 선언이에요.
		void func();

		// S 소속, static 붙은 멤버 함수 선언이에요.
		static void func_static();

		// S 소속 구조체 정의예요.
		struct Inner
		{
			// Inner 소속 멤버 변수 선언이에요.
			int data;

			// Inner 소속, lookup 양상 구경용 멤버 함수 선언이에요.
			static void funcForTest(int arg);
		};

		// S 소속, lookup 양상 구경용 멤버 함수 선언이에요.
		static void funcForTest(int arg);
	};

	// yeshi 소속 (비멤버) 변수 선언이에요.
	int data;

	// yeshi 소속, lookup 양상 구경용 (비멤버) 함수 선언이에요.
	void funcForTest(int arg);
}

// global 소속 (비멤버) 변수 선언이에요.
int data;

// global 소속, lookup 양상 구경용 (비멤버) 함수 선언이에요.
void funcForTest(int arg);

// global 소속 구조체에 대한 구조체 정의예요.
struct S
{
	// S 소속 멤버 변수 선언이에요.
	int data;
};



/*
	위에서 선언만 해 둔 이름들에 대한 정의를 이 아래에 적어 두었어요.
	- 소개만 해 둔 struct S_DefinedOutside에 대한 정의도 있어요
*/

// yeshi 소속 구조체에 대한 구조체 정의예요.
struct yeshi::S_DefinedOutside
{
	S data;

	// S_DefinedOutside 소속, lookup 양상 구경용 멤버 함수 선언이에요.
	static void funcForTest(int arg);
};


// S 소속, static 안 붙은 멤버 변수에 대한 정의예요?
//int yeshi::S::data = 3;

// S 소속, static 붙은? 멤버 변수에 대한 정의예요?
int yeshi::S::data_static = 3;

// S 소속, static 안 붙은 멤버 함수에 대한 정의예요.
void yeshi::S::func() { }

// S 소속, static 붙은? 멤버 함수에 대한 정의예요.
void yeshi::S::func_static() { }


/*
	TODO#2 - One Definition Rule

	이번에는 여기에, 정의 또는 '정의를 수반하는 선언'을 여럿 적어볼 거예요.
	사실 위에서 선언된 모든 이름들에 대한 정의는 이미 잘 되어 있으므로,
	여기에 적은 내용이 해당 이름에 대한 '재'정의를 하는 셈이 되면
	우리의 VS가 바로 반응해 주거나, 녹색 화살표 눌렀을 때 오류를 내 줄 거예요.

	- 선언 문제는 오로지 이 .cpp 파일 내용만 보고도 찾을 수 있지만,
	  정의 문제는 어떤 이름에 대한 (위치) 정의를 다른 파일에서 수행할 수도 있으므로
	  VS가 즉시 빨간 줄을 그어주기 어려워요 
*/



// 그냥 이렇게 두면 얘는 'global 소속' funcForTest()에 대한 정의가 돼요.
void funcForTest(int arg)
{
	/*
		소속 관계를 배제하고 나열한, 지금까지 등장한 이름 목록:

		yeshi
		S_DefinedOutside
		S
		data
		data_static
		func
		func_static
		Inner
		funcForTest
		arg
	*/


	/*
		TODO#1 - 소속 관계

		여기에서 각 이름들을 사용하면서
		컴파일러가 해당 이름에 대한 선언을 어떻게 lookup하는지 구경해볼 거예요
	*/


	
}




/*
	☆
	#define directive를 가지고 함수 정의 비슷한 무언가를 만들 수 있어요.
	궁금한 친구들은 강사에게 물어봐 주세요.
*/
#define PRINT_EXPRESSION(exp, width)													\
	(																					\
		std::cout << std::setw(( width ) + 2) << ###exp ": " << ( exp ) << std::endl	\
	)



int main()
{
	/*
		TODO#3 - 포함 관계 및 static specifier

		이 아래 코드를 구경해 본 다음, 포함 관계가 성립하는 경우를 살펴볼 거예요.
	*/
	
	yeshi::S s1, s2;

	// Nonstatic (선언에 static 안 붙인) Data 멤버 이름을 사용하고 있어요.
	PRINT_EXPRESSION(&s1,      sizeof "&s1.data");
	PRINT_EXPRESSION(&s1.data, sizeof "&s1.data");
	PRINT_EXPRESSION(&s2,      sizeof "&s1.data");
	PRINT_EXPRESSION(&s2.data, sizeof "&s1.data");
	std::cout << std::endl;

	// Static (선언에 static 붙인) Data 멤버 이름을 사용하고 있어요.
	PRINT_EXPRESSION(&s1, sizeof "&s1.data_static");
	PRINT_EXPRESSION(&s1.data_static, sizeof "&s1.data_static");
	PRINT_EXPRESSION(&s2, sizeof "&s1.data_static");
	PRINT_EXPRESSION(&s2.data_static, sizeof "&s1.data_static");



	// Nonstatic Code 멤버 이름을 사용하고 있어요.
	// 아래 멤버 함수 호출식을 조금씩 고쳐볼 예정이에요.
	s1.func();
	s2.func();


	// Static Code 멤버 이름을 사용하고 있어요.
	// 아래 함수 호출식을 조금씩 고쳐볼 예정이에요.
	s1.func_static();
	s2.func_static();

	
	// 여기까지 구경해 본 다음,
	// 위에서 사용해 본 . 연산자를 :: 연산자로 교체해볼 거예요.

	
	// ☆
	// . 연산자를 곁들여 사용해야 하는 Nonstatic Data / Code 멤버의 경우
	// 해당 멤버에 대한 포인터 값을 미리 담아 두었다가 활용할 수 있어요.
	

	return 0;
}